# __init__.py
from .FEAS import *  # Import necessary components from feas.py
